package project05;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import pictureSearch.Stuff;

public class StuffPanel extends JPanel {
    private static final long serialVersionUID = 3811037325320199526L;
    private JLabel stuffTypeLabel = new JLabel("Type");
    private JLabel stuffNameLabel = new JLabel("Name");
    private JLabel stuffTagsLabel = new JLabel("Tags");

    public StuffPanel() {
        setLayout(new GridLayout(3, 2, 1, 0));
        add(stuffTypeLabel);
        add(new JTextField(20));
        add(stuffNameLabel);
        add(new JTextField(20));
        add(stuffTagsLabel);
        add(new JTextField(20));
        setBorder(new LineBorder(Color.BLACK, 1));
    }

    public StuffPanel(Stuff stuff) {
        setLayout(new GridLayout(3, 2, 1, 0));
        add(stuffTypeLabel);
        add(new JTextField(stuff.getStuffType()));
        add(stuffNameLabel);
        add(new JTextField(stuff.getStuffName()));
        add(stuffTagsLabel);
        add(new JTextField(stuff.getStuffTags()));
        setBorder(new LineBorder(Color.BLACK, 1));
    }
}

