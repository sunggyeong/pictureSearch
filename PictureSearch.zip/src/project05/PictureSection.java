package project05;

import javax.swing.*;
import pictureSearch.PictureList;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class PictureSection extends JFrame {
    private static final long serialVersionUID = 7165553339370634695L;
    private JButton allPictures = new JButton("Show All Pictures");
    private JButton addButton = new JButton("ADD");
    private JButton deleteButton = new JButton("DELETE");
    private JButton loadButton = new JButton("LOAD");
    private JButton saveButton = new JButton("SAVE");
    private JButton searchButton = new JButton("SEARCH");
    private ArrayList<PicturePanel> list = new ArrayList<>();
    private PictureList pictureList;

    public PictureSection(String infoFileName) {
        setTitle("Simple Picture Search");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // 화면 중앙에 배치

        try {
            pictureList = new PictureList(infoFileName);
        } catch (IllegalArgumentException e) {
            System.err.println("Error creating PictureList: " + e.getMessage());
            e.printStackTrace();
        }

        JPanel buttons = new JPanel();
        buttons.setLayout(new GridLayout(5, 1));
        buttons.add(addButton);
        buttons.add(deleteButton);
        buttons.add(loadButton);
        buttons.add(saveButton);
        buttons.add(searchButton);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS)); // 세로로 PicturePanel들을 나열
        JScrollPane scrollPane = new JScrollPane(contentPanel); // 스크롤 가능한 패널

        for (int i = 0; i < pictureList.size(); i++) {
            PicturePanel p = new PicturePanel(pictureList.get(i), pictureList.get(i).getImagePath());
            list.add(p);
            contentPanel.add(p);
        }

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(allPictures, BorderLayout.NORTH);
        mainPanel.add(buttons, BorderLayout.EAST);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);

        // Add button action listener
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddPicture addPictureFrame = new AddPicture();
                addPictureFrame.setVisible(true);
            }
        });

        // Search button action listener
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SearchPicture searchPictureFrame = new SearchPicture();
                searchPictureFrame.setVisible(true);
            }
        });

    }
}


	



