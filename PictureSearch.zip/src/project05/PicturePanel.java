package project05;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import pictureSearch.Picture;
import pictureSearch.Stuff;

public class PicturePanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private Picture picture;
    private String imagePath;

    public PicturePanel(Picture picture, String imagePath) {
        this.picture = picture;
        this.imagePath = imagePath;

        System.out.println("Creating PicturePanel for: " + imagePath);

        // 이미지 파일의 절대 경로 확인
        File imageFile = new File("src/project05/" + imagePath);  // 상대 경로를 절대 경로로 변환
        System.out.println("Checking file: " + imageFile.getAbsolutePath());
        if (!imageFile.exists()) {
            System.err.println("Image not found: " + imageFile.getAbsolutePath());
        } else {
            System.out.println("Image found: " + imageFile.getAbsolutePath());
        }

        // 이미지 크기 조정
        ImageIcon icon = new ImageIcon(imageFile.getAbsolutePath());
        Image image = icon.getImage(); // ImageIcon을 Image 객체로 변환
        Image scaledImage = image.getScaledInstance(200, 200, Image.SCALE_SMOOTH); // 원하는 크기로 조정 (200x200)
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel imageLabel = new JLabel(scaledIcon);

        // 레이아웃 설정
        setLayout(new BorderLayout());

        // 이미지를 BorderLayout.WEST에 추가
        add(imageLabel, BorderLayout.WEST);

        // 정보 패널을 생성하고 태그, 타임스탬프 및 코멘트를 추가
        JPanel infoPanel = new JPanel(new GridLayout(1,2));
        
        JLabel tagLabel = new JLabel(picture.getImageTag());
        JLabel timestampLabel = new JLabel(picture.getTimeStamp() != null ? picture.getTimeStamp().toString() : "No timestamp");
        JLabel commentLabel = new JLabel(picture.getImageComment());
        
        infoPanel.add(timestampLabel);
        infoPanel.add(tagLabel);
        add(commentLabel, BorderLayout.SOUTH);
        
        add(infoPanel, BorderLayout.NORTH);

        // Stuff 정보를 담을 패널 생성
        JPanel stuffPanelContainer = new JPanel();
        stuffPanelContainer.setLayout(new BoxLayout(stuffPanelContainer, BoxLayout.Y_AXIS));
        for (Stuff stuff : picture.getPictureStuffs()) {
            StuffPanel stuffPanel = new StuffPanel(stuff);
            stuffPanelContainer.add(stuffPanel);
        }
        add(stuffPanelContainer, BorderLayout.CENTER);
        setBorder(new LineBorder(Color.BLACK,1));
    }
    
}





