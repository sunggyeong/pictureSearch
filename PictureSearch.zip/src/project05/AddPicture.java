package project05;

import javax.swing.*;
import java.awt.*;

public class AddPicture extends JFrame {
    private static final long serialVersionUID = -4911243125153381529L;

    public AddPicture() {
        setTitle("Add a Picture");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // 창 닫기 설정
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); // BorderLayout 사용

        // Time and Picture Input Panel
        JPanel p1 = new JPanel();
        p1.add(new JLabel("Time"));
        p1.add(new JTextField(25));
        p1.add(new JLabel("(Picture)"));
        p1.add(new JTextField(25));
        add(p1, BorderLayout.NORTH);

        // Select Image File Button and StuffPanel
        JPanel p2 = new JPanel(new BorderLayout());
        JButton select = new JButton("Select Image File");
        p2.add(select, BorderLayout.WEST);

        StuffPanel stuffPanel = new StuffPanel();
        p2.add(stuffPanel, BorderLayout.CENTER);

        add(p2, BorderLayout.CENTER);

        // Comments and Action Buttons
     // Comments and Action Buttons
        JPanel p3 = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        p3.add(new JLabel("Comments"), gbc);
        p3.add(new JTextField(30), gbc);
        gbc.gridy = 1; // 다음 요소는 새로운 행에 추가
        p3.add(new JButton("More Stuff"), gbc);
        p3.add(new JButton("OK-INPUT END"), gbc);

        add(p3, BorderLayout.SOUTH);

    }


}